document.addEventListener('DOMContentLoaded', function() {
    const display = document.getElementById('display');
    const buttons = document.querySelectorAll('.btn');
    const equalButton = document.querySelector('.equal');

    let currentInput = '';
    let previousInput = '';
    let operation = null;

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const value = button.textContent;

            if (value >= '0' && value <= '9' || value === '.') {
                currentInput += value;
                display.value = currentInput;
            } else if (value === 'C') {
                currentInput = '';
                previousInput = '';
                operation = null;
                display.value = '';
            } else if (value === '←') {
                currentInput = currentInput.slice(0, -1);
                display.value = currentInput;
            } else if (['+', '-', 'x', '/'].includes(value)) {
                if (currentInput !== '') {
                    if (previousInput !== '') {
                        calculate();
                    }
                    operation = value;
                    previousInput = currentInput;
                    currentInput = '';
                }
            }
        });
    });

    equalButton.addEventListener('click', calculate);

    function calculate() {
        if (currentInput !== '' && previousInput !== '' && operation) {
            let result;
            const prev = parseFloat(previousInput);
            const current = parseFloat(currentInput);

            switch (operation) {
                case '+':
                    result = prev + current;
                    break;
                case '-':
                    result = prev - current;
                    break;
                case 'x':
                    result = prev * current;
                    break;
                case '/':
                    result = prev / current;
                    break;
                default:
                    return;
            }

            display.value = result;
            currentInput = result.toString();
            previousInput = '';
            operation = null;
        }
    }
});


